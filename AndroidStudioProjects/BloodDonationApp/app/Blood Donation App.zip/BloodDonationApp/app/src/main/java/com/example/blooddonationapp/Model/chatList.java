package com.example.blooddonationapp.Model;

public class chatList {
    public String id;

    public chatList(String id) {
        this.id = id;
    }

    public chatList() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
