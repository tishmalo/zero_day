package com.example.blooddonationapp.Notification;

public class MyResponse {

    public int success;
}
